package com.vano.floatingai

import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.WebView
import org.json.JSONObject
import org.json.JSONTokener

/**
 * Menjalankan skrip uji sederhana pada halaman yang dimuat di WebView milik aplikasi ini,
 * langkah demi langkah dan terlihat di layar (elemen disorot). Hanya berjalan selama host
 * halaman sama dengan host yang didaftarkan pengguna, dan bisa dihentikan kapan saja.
 *
 * Sintaks skrip, satu perintah per baris (baris diawali // adalah komentar):
 *   isi <selector> = <teks>        mengisi kolom teks
 *   klik <selector>                mengeklik elemen (juga untuk tombol Next)
 *   next <selector>                sama dengan klik
 *   enter <selector>               mengirim tombol Enter ke elemen
 *   tunggu <milidetik>             jeda
 *   ada <selector>                 memeriksa elemen ada dan terlihat
 *   berisi <selector> = <teks>     memeriksa teks atau nilai elemen mengandung teks
 */
class DemoInteractionManager(
    private val webView: WebView,
    private val listener: Listener
) {

    interface Listener {
        fun onLog(message: String)
        fun onRunningChanged(running: Boolean)
    }

    sealed class Step {
        abstract val label: String

        data class Fill(val selector: String, val text: String) : Step() {
            override val label: String get() = "isi $selector (${text.length} karakter)"
        }

        data class Click(val selector: String) : Step() {
            override val label: String get() = "klik $selector"
        }

        data class Enter(val selector: String) : Step() {
            override val label: String get() = "enter $selector"
        }

        data class Wait(val millis: Long) : Step() {
            override val label: String get() = "tunggu $millis ms"
        }

        data class Exists(val selector: String) : Step() {
            override val label: String get() = "ada $selector"
        }

        data class Contains(val selector: String, val text: String) : Step() {
            override val label: String get() = "berisi $selector (${text.length} karakter)"
        }
    }

    sealed class ParseResult {
        data class Success(val steps: List<Step>) : ParseResult()
        data class Error(val line: Int, val message: String) : ParseResult()
    }

    companion object {
        const val MAX_STEPS = 100
        const val MAX_WAIT_MS = 10_000L
        private const val START_DELAY_MS = 500L
        private const val STEP_DELAY_MS = 700L // jeda antar langkah agar terlihat jelas
        private const val STEP_TIMEOUT_MS = 5_000L

        fun parse(script: String): ParseResult {
            val steps = mutableListOf<Step>()
            script.lines().forEachIndexed { index, rawLine ->
                val lineNumber = index + 1
                val line = rawLine.trim()
                if (line.isEmpty() || line.startsWith("//")) return@forEachIndexed

                val space = line.indexOf(' ')
                val command = (if (space < 0) line else line.substring(0, space)).lowercase()
                val rest = if (space < 0) "" else line.substring(space + 1).trim()

                when (command) {
                    "isi", "berisi" -> {
                        val pair = splitAssignment(rest)
                        if (pair == null || pair.first.isEmpty()) {
                            return ParseResult.Error(lineNumber, "format: $command <selector> = <teks>")
                        }
                        steps.add(
                            if (command == "isi") Step.Fill(pair.first, pair.second)
                            else Step.Contains(pair.first, pair.second)
                        )
                    }
                    "klik", "next" -> {
                        if (rest.isEmpty()) return ParseResult.Error(lineNumber, "format: $command <selector>")
                        steps.add(Step.Click(rest))
                    }
                    "enter" -> {
                        if (rest.isEmpty()) return ParseResult.Error(lineNumber, "format: enter <selector>")
                        steps.add(Step.Enter(rest))
                    }
                    "ada" -> {
                        if (rest.isEmpty()) return ParseResult.Error(lineNumber, "format: ada <selector>")
                        steps.add(Step.Exists(rest))
                    }
                    "tunggu" -> {
                        val millis = rest.toLongOrNull()
                            ?: return ParseResult.Error(lineNumber, "format: tunggu <milidetik>")
                        steps.add(Step.Wait(millis.coerceIn(0L, MAX_WAIT_MS)))
                    }
                    else -> return ParseResult.Error(lineNumber, "perintah tidak dikenal: $command")
                }
            }
            if (steps.isEmpty()) return ParseResult.Error(0, "skrip kosong")
            if (steps.size > MAX_STEPS) {
                return ParseResult.Error(0, "maksimal $MAX_STEPS langkah")
            }
            return ParseResult.Success(steps)
        }

        /** Memisahkan "<selector> = <teks>". Teks boleh kosong. */
        private fun splitAssignment(rest: String): Pair<String, String>? {
            val i = rest.indexOf(" = ")
            if (i >= 0) return Pair(rest.substring(0, i).trim(), rest.substring(i + 3))
            if (rest.endsWith(" =")) return Pair(rest.removeSuffix(" =").trim(), "")
            return null
        }

        private val HELPER_JS = """
(function () {
  if (window.__faiRun) return;
  function res(ok, msg) { return JSON.stringify({ ok: ok, msg: msg || '' }); }
  function highlight(el) {
    try {
      var old = el.style.outline;
      el.style.outline = '3px solid #ff9f1c';
      setTimeout(function () { el.style.outline = old; }, 700);
    } catch (e) {}
  }
  function visible(el) {
    return !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length);
  }
  window.__faiRun = function (kind, sel, arg) {
    try {
      var el = document.querySelector(sel);
      if (!el) return res(false, 'elemen tidak ditemukan');
      if (kind === 'exists') {
        return visible(el) ? res(true) : res(false, 'elemen ada tetapi tidak terlihat');
      }
      if (kind === 'contains') {
        var t = (typeof el.value === 'string' && el.value !== '') ? el.value : (el.innerText || el.textContent || '');
        return t.indexOf(arg) >= 0 ? res(true) : res(false, 'teks tidak mengandung nilai yang diharapkan');
      }
      try { el.scrollIntoView({ block: 'center' }); } catch (e) {}
      highlight(el);
      if (kind === 'fill') {
        if (el instanceof HTMLInputElement || el instanceof HTMLTextAreaElement || el instanceof HTMLSelectElement) {
          el.focus();
          var proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype
                    : (el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype);
          var d = Object.getOwnPropertyDescriptor(proto, 'value');
          if (d && d.set) { d.set.call(el, arg); } else { el.value = arg; }
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
          return res(true);
        }
        if (el.isContentEditable) {
          el.focus();
          el.textContent = arg;
          el.dispatchEvent(new Event('input', { bubbles: true }));
          return res(true);
        }
        return res(false, 'elemen bukan kolom teks');
      }
      if (kind === 'click') { el.click(); return res(true); }
      if (kind === 'enter') {
        el.focus();
        ['keydown', 'keypress', 'keyup'].forEach(function (type) {
          el.dispatchEvent(new KeyboardEvent(type, { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true }));
        });
        return res(true);
      }
      return res(false, 'perintah tidak dikenal');
    } catch (e) {
      return res(false, 'galat: ' + e.message);
    }
  };
})();
"""
    }

    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var runToken = 0
    private var steps: List<Step> = emptyList()
    private var index = 0
    private var passed = 0
    private var failed = 0
    private var allowedHost = ""

    val isRunning: Boolean
        get() = running

    fun run(steps: List<Step>, allowedHost: String) {
        if (running) return
        this.steps = steps
        this.allowedHost = allowedHost
        index = 0
        passed = 0
        failed = 0
        running = true
        runToken++
        listener.onRunningChanged(true)
        listener.onLog("Uji dimulai (${steps.size} langkah). Tekan Stop untuk menghentikan.")
        scheduleNext(START_DELAY_MS)
    }

    fun stop() {
        if (running) finish(stopped = true)
    }

    fun destroy() {
        running = false
        runToken++
        handler.removeCallbacksAndMessages(null)
    }

    // ---------- Internal ----------

    private fun scheduleNext(delayMs: Long) {
        val token = runToken
        handler.postDelayed({ if (running && token == runToken) executeNext() }, delayMs)
    }

    private fun executeNext() {
        if (index >= steps.size) {
            finish(stopped = false)
            return
        }
        if (!isHostAllowed()) {
            listener.onLog("Berhenti: halaman berpindah ke luar domain yang diizinkan ($allowedHost).")
            failed++
            finish(stopped = true)
            return
        }

        val step = steps[index]
        val number = index + 1

        if (step is Step.Wait) {
            record(number, step, true, "")
            return
        }

        val token = runToken
        var answered = false
        val timeout = Runnable {
            if (running && token == runToken && !answered) {
                answered = true
                record(number, step, false, "tidak ada respons dari halaman")
            }
        }
        handler.postDelayed(timeout, STEP_TIMEOUT_MS)

        webView.evaluateJavascript(buildScript(step)) { raw ->
            if (answered || !running || token != runToken) return@evaluateJavascript
            answered = true
            handler.removeCallbacks(timeout)
            val (ok, message) = parseResult(raw)
            record(number, step, ok, message)
        }
    }

    private fun record(number: Int, step: Step, ok: Boolean, message: String) {
        if (ok) {
            passed++
            listener.onLog("[$number] OK      ${step.label}")
        } else {
            failed++
            listener.onLog("[$number] GAGAL   ${step.label}: $message")
        }
        index++
        scheduleNext(if (step is Step.Wait) step.millis else STEP_DELAY_MS)
    }

    private fun finish(stopped: Boolean) {
        running = false
        runToken++
        handler.removeCallbacksAndMessages(null)
        val total = steps.size
        listener.onLog(
            if (stopped) "Uji dihentikan. $passed OK, $failed gagal dari $total langkah."
            else "Uji selesai: $passed OK, $failed gagal dari $total langkah."
        )
        listener.onRunningChanged(false)
    }

    private fun isHostAllowed(): Boolean =
        Uri.parse(webView.url ?: "").host == allowedHost

    private fun buildScript(step: Step): String {
        val (kind, selector, arg) = when (step) {
            is Step.Fill -> Triple("fill", step.selector, step.text)
            is Step.Click -> Triple("click", step.selector, "")
            is Step.Enter -> Triple("enter", step.selector, "")
            is Step.Exists -> Triple("exists", step.selector, "")
            is Step.Contains -> Triple("contains", step.selector, step.text)
            is Step.Wait -> Triple("wait", "", "")
        }
        return HELPER_JS + "\nwindow.__faiRun(" +
            JSONObject.quote(kind) + "," + JSONObject.quote(selector) + "," + JSONObject.quote(arg) + ");"
    }

    private fun parseResult(raw: String?): Pair<Boolean, String> {
        if (raw == null || raw == "null") return Pair(false, "tidak ada respons dari halaman")
        return try {
            val inner = JSONTokener(raw).nextValue() as? String
                ?: return Pair(false, "respons tidak dikenali")
            val obj = JSONObject(inner)
            Pair(obj.optBoolean("ok"), obj.optString("msg"))
        } catch (e: Exception) {
            Pair(false, "respons tidak dikenali")
        }
    }
}
