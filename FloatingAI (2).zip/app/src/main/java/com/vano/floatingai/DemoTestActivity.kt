package com.vano.floatingai

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import com.vano.floatingai.databinding.ActivityDemoTestBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Halaman uji interaksi. Halaman dimuat di WebView milik aplikasi ini, hanya dari host yang
 * didaftarkan pengguna, dan otomatisasi selalu terlihat serta bisa dihentikan dengan Stop.
 */
class DemoTestActivity : AppCompatActivity(), DemoInteractionManager.Listener {

    companion object {
        private const val SAMPLE_URL = "https://appassets.androidplatform.net/assets/demo.html"
        private const val MAX_LOG_LINES = 300
        private const val SAMPLE_SCRIPT = """// Contoh untuk halaman uji bawaan. Baris yang diawali // adalah komentar.
isi #nama = Budi
enter #nama
berisi #enter-info = Enter diterima
isi #pesan = Halo dari uji otomatis
klik #btn-kirim
berisi #hasil = Terkirim
klik #btn-next
ada #langkah2"""
    }

    private lateinit var binding: ActivityDemoTestBinding
    private lateinit var manager: DemoInteractionManager
    private lateinit var assetLoader: WebViewAssetLoader

    private var allowedHost: String? = null
    private val logLines = ArrayDeque<String>()
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDemoTestBinding.inflate(layoutInflater)
        setContentView(binding.root)

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        setupWebView()
        manager = DemoInteractionManager(binding.webView, this)

        binding.inputDemoUrl.setText(AppPreferences.getDemoUrl(this).orEmpty())
        binding.inputScript.setText(AppPreferences.getDemoScript(this) ?: SAMPLE_SCRIPT)
        onRunningChanged(false)

        binding.btnLoad.setOnClickListener { loadFromInput() }
        binding.btnLoadSample.setOnClickListener {
            binding.inputDemoUrl.setText(SAMPLE_URL)
            if (binding.inputScript.text.isNullOrBlank()) binding.inputScript.setText(SAMPLE_SCRIPT)
            loadFromInput()
        }
        binding.btnRun.setOnClickListener { onRunClicked() }
        binding.btnStop.setOnClickListener { manager.stop() }
        binding.btnCopyLog.setOnClickListener { copyLog() }
        binding.btnClearLog.setOnClickListener {
            logLines.clear()
            binding.txtLog.text = ""
        }
        binding.btnBack.setOnClickListener { finish() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.webView.canGoBack()) {
                    binding.webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    override fun onStop() {
        // Otomatisasi tidak boleh berjalan saat layar ini tidak terlihat.
        if (::manager.isInitialized && manager.isRunning) {
            manager.stop()
        }
        super.onStop()
    }

    override fun onDestroy() {
        if (::manager.isInitialized) manager.destroy()
        binding.webView.stopLoading()
        (binding.webView.parent as? ViewGroup)?.removeView(binding.webView)
        binding.webView.destroy()
        super.onDestroy()
    }

    // ---------- WebView ----------

    private fun setupWebView() {
        val settings = binding.webView.settings
        settings.javaScriptEnabled = true // dibutuhkan agar skrip uji bisa berjalan
        settings.domStorageEnabled = true
        settings.allowFileAccess = false
        settings.allowContentAccess = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW

        binding.webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val host = request.url.host
                if (request.url.scheme == "https" && host == allowedHost) return false
                appendLog("Navigasi ke ${host ?: "alamat lain"} diblokir. Hanya $allowedHost yang diizinkan.")
                return true
            }

            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)
        }
    }

    private fun loadFromInput() {
        val raw = binding.inputDemoUrl.text?.toString().orEmpty().trim()
        val uri = Uri.parse(raw)
        if (uri.scheme != "https" || uri.host.isNullOrBlank()) {
            binding.layoutDemoUrl.error = getString(R.string.demo_url_invalid)
            return
        }
        binding.layoutDemoUrl.error = null
        manager.stop()
        allowedHost = uri.host
        AppPreferences.setDemoUrl(this, raw)
        binding.webView.loadUrl(raw)
        appendLog("Memuat halaman. Domain yang diizinkan: ${uri.host}")
    }

    // ---------- Menjalankan uji ----------

    private fun onRunClicked() {
        val host = allowedHost
        if (host == null) {
            Toast.makeText(this, R.string.demo_load_first, Toast.LENGTH_LONG).show()
            return
        }
        if (!binding.checkConsent.isChecked) {
            Toast.makeText(this, R.string.demo_consent_needed, Toast.LENGTH_LONG).show()
            return
        }
        val script = binding.inputScript.text?.toString().orEmpty()
        AppPreferences.setDemoScript(this, script)

        when (val parsed = DemoInteractionManager.parse(script)) {
            is DemoInteractionManager.ParseResult.Error -> {
                val where = if (parsed.line > 0) "baris ${parsed.line}: " else ""
                appendLog("Skrip tidak valid, $where${parsed.message}")
            }
            is DemoInteractionManager.ParseResult.Success -> manager.run(parsed.steps, host)
        }
    }

    // ---------- DemoInteractionManager.Listener ----------

    override fun onLog(message: String) {
        appendLog(message)
    }

    override fun onRunningChanged(running: Boolean) {
        binding.txtRunBanner.visibility = if (running) View.VISIBLE else View.GONE
        binding.btnRun.isEnabled = !running
        binding.btnStop.isEnabled = running
        binding.inputScript.isEnabled = !running
    }

    // ---------- Log ----------

    private fun appendLog(message: String) {
        logLines.addLast("${timeFormat.format(Date())}  $message")
        while (logLines.size > MAX_LOG_LINES) logLines.removeFirst()
        binding.txtLog.text = logLines.joinToString("\n")
    }

    private fun copyLog() {
        val text = binding.txtLog.text?.toString().orEmpty()
        if (text.isBlank()) return
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Log uji", text))
        Toast.makeText(this, R.string.demo_log_copied, Toast.LENGTH_SHORT).show()
    }
}
