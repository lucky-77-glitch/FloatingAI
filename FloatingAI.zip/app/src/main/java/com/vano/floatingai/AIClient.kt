package com.vano.floatingai

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException

/**
 * Klien HTTPS ke backend sendiri (bukan langsung ke penyedia AI), sehingga
 * tidak ada API key di aplikasi. Isi percakapan tidak pernah dicatat ke log.
 */
class AIClient {

    data class Turn(val role: String, val content: String)

    enum class ErrorKind {
        NETWORK, TIMEOUT, UNAUTHORIZED, RATE_LIMITED, INPUT_TOO_LARGE, SERVER, BAD_RESPONSE
    }

    sealed class Result {
        data class Success(val answer: String, val truncated: Boolean) : Result()
        data class Failure(val kind: ErrorKind, val detail: String? = null) : Result()
    }

    companion object {
        const val MAX_ANSWER_CHARS = 6000
        private const val CONNECT_TIMEOUT_MS = 15_000
        private const val ASK_READ_TIMEOUT_MS = 70_000
        private const val HEALTH_READ_TIMEOUT_MS = 60_000 // server gratis bisa lambat "bangun"
        private const val MAX_RESPONSE_BYTES = 256 * 1024
    }

    private val executor: ExecutorService = Executors.newCachedThreadPool()
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var generation = 0

    /** Kirim pertanyaan. Hasil selalu dikembalikan di main thread. */
    fun ask(
        baseUrl: String,
        token: String,
        screenText: String,
        question: String,
        history: List<Turn>,
        onResult: (Result) -> Unit
    ) {
        val myGeneration = ++generation
        try {
            executor.execute {
                val result = try {
                    performAsk(baseUrl, token, screenText, question, history)
                } catch (e: Exception) {
                    Result.Failure(ErrorKind.NETWORK)
                }
                mainHandler.post {
                    // Hasil permintaan yang sudah dibatalkan dibuang.
                    if (myGeneration == generation) onResult(result)
                }
            }
        } catch (e: RejectedExecutionException) {
            // Executor sudah dimatikan; abaikan.
        }
    }

    /** Membatalkan hasil permintaan yang sedang berjalan (callback tidak akan dipanggil). */
    fun cancelPending() {
        generation++
    }

    /** Uji GET /health. Hasil dikembalikan di main thread. */
    fun checkHealth(baseUrl: String, onResult: (Boolean) -> Unit) {
        try {
            executor.execute {
                val ok = try {
                    performHealth(baseUrl)
                } catch (e: Exception) {
                    false
                }
                mainHandler.post { onResult(ok) }
            }
        } catch (e: RejectedExecutionException) {
            // abaikan
        }
    }

    fun shutdown() {
        generation++
        executor.shutdownNow()
    }

    // ---------- Internal ----------

    private fun performHealth(baseUrl: String): Boolean {
        var connection: HttpURLConnection? = null
        try {
            val conn = URL(baseUrl.trimEnd('/') + "/health").openConnection() as HttpURLConnection
            connection = conn
            conn.requestMethod = "GET"
            conn.connectTimeout = CONNECT_TIMEOUT_MS
            conn.readTimeout = HEALTH_READ_TIMEOUT_MS
            if (conn.responseCode != 200) return false
            val body = readLimited(conn.inputStream) ?: return false
            return JSONObject(body).optString("status") == "ok"
        } finally {
            connection?.disconnect()
        }
    }

    private fun performAsk(
        baseUrl: String,
        token: String,
        screenText: String,
        question: String,
        history: List<Turn>
    ): Result {
        var connection: HttpURLConnection? = null
        try {
            val conn = URL(baseUrl.trimEnd('/') + "/api/ask").openConnection() as HttpURLConnection
            connection = conn
            conn.requestMethod = "POST"
            conn.connectTimeout = CONNECT_TIMEOUT_MS
            conn.readTimeout = ASK_READ_TIMEOUT_MS
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("Accept", "application/json")
            if (token.isNotBlank()) {
                conn.setRequestProperty("Authorization", "Bearer $token")
            }

            val historyJson = JSONArray()
            for (turn in history) {
                historyJson.put(JSONObject().put("role", turn.role).put("content", turn.content))
            }
            val payload = JSONObject()
                .put("screenText", screenText)
                .put("question", question)
                .put("history", historyJson)

            conn.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = readLimited(stream)

            return when (code) {
                in 200..299 -> parseSuccess(body)
                401, 403 -> Result.Failure(ErrorKind.UNAUTHORIZED)
                413 -> Result.Failure(ErrorKind.INPUT_TOO_LARGE)
                429 -> Result.Failure(ErrorKind.RATE_LIMITED)
                408, 504 -> Result.Failure(ErrorKind.TIMEOUT)
                else -> Result.Failure(ErrorKind.SERVER, buildDetail(code, body))
            }
        } catch (e: SocketTimeoutException) {
            return Result.Failure(ErrorKind.TIMEOUT)
        } catch (e: JSONException) {
            return Result.Failure(ErrorKind.BAD_RESPONSE)
        } catch (e: IOException) {
            return Result.Failure(ErrorKind.NETWORK)
        } finally {
            connection?.disconnect()
        }
    }

    /** Kode HTTP + penyebab dari backend (jika ada), untuk membantu diagnosis. */
    private fun buildDetail(httpCode: Int, body: String?): String {
        val fromBackend = try {
            if (body.isNullOrBlank()) null
            else JSONObject(body).optString("detail").trim().take(300).takeIf { it.isNotEmpty() }
        } catch (e: JSONException) {
            null
        }
        return if (fromBackend != null) "HTTP $httpCode - $fromBackend" else "HTTP $httpCode"
    }

    private fun parseSuccess(body: String?): Result {
        if (body.isNullOrBlank()) return Result.Failure(ErrorKind.BAD_RESPONSE)
        val json = JSONObject(body)
        var answer = json.optString("answer").trim()
        if (answer.isEmpty()) return Result.Failure(ErrorKind.BAD_RESPONSE)
        var truncated = json.optBoolean("truncated", false)
        if (answer.length > MAX_ANSWER_CHARS) {
            answer = answer.take(MAX_ANSWER_CHARS)
            truncated = true
        }
        return Result.Success(answer, truncated)
    }

    /** Membaca respons dengan batas ukuran. Mengembalikan null jika terlalu besar. */
    private fun readLimited(stream: InputStream?): String? {
        if (stream == null) return ""
        stream.use { input ->
            val out = ByteArrayOutputStream()
            val buffer = ByteArray(8192)
            var total = 0
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                total += read
                if (total > MAX_RESPONSE_BYTES) return null
                out.write(buffer, 0, read)
            }
            return out.toString("UTF-8")
        }
    }
}
