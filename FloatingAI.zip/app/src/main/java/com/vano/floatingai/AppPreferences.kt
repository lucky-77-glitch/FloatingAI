package com.vano.floatingai

import android.content.Context

object AppPreferences {
    private const val FILE_NAME = "floating_ai_prefs"
    private const val KEY_BACKEND_URL = "backend_url"
    private const val KEY_ACCESS_TOKEN = "access_token"
    private const val KEY_BACKEND_TESTED = "backend_tested"
    private const val KEY_PANEL_X = "panel_x"
    private const val KEY_PANEL_Y = "panel_y"
    private const val KEY_PANEL_W = "panel_w"
    private const val KEY_PANEL_H = "panel_h"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)

    fun getBackendUrl(context: Context): String? =
        prefs(context).getString(KEY_BACKEND_URL, null)

    fun setBackendUrl(context: Context, url: String) {
        val changed = getBackendUrl(context).orEmpty() != url
        val editor = prefs(context).edit().putString(KEY_BACKEND_URL, url)
        if (changed) editor.putBoolean(KEY_BACKEND_TESTED, false)
        editor.apply()
    }

    /** Kunci akses backend yang dimasukkan pengguna (bukan API key AI). */
    fun getAccessToken(context: Context): String? =
        prefs(context).getString(KEY_ACCESS_TOKEN, null)

    fun setAccessToken(context: Context, token: String) {
        prefs(context).edit().putString(KEY_ACCESS_TOKEN, token).apply()
    }

    fun isBackendTested(context: Context): Boolean =
        prefs(context).getBoolean(KEY_BACKEND_TESTED, false)

    fun setBackendTested(context: Context, tested: Boolean) {
        prefs(context).edit().putBoolean(KEY_BACKEND_TESTED, tested).apply()
    }

    /** Posisi dan ukuran panel dalam piksel: x, y, lebar, tinggi. Null jika belum pernah disimpan. */
    fun getPanelBounds(context: Context): IntArray? {
        val p = prefs(context)
        if (!p.contains(KEY_PANEL_W)) return null
        return intArrayOf(
            p.getInt(KEY_PANEL_X, 0),
            p.getInt(KEY_PANEL_Y, 0),
            p.getInt(KEY_PANEL_W, 0),
            p.getInt(KEY_PANEL_H, 0)
        )
    }

    fun setPanelBounds(context: Context, x: Int, y: Int, w: Int, h: Int) {
        prefs(context).edit()
            .putInt(KEY_PANEL_X, x).putInt(KEY_PANEL_Y, y)
            .putInt(KEY_PANEL_W, w).putInt(KEY_PANEL_H, h)
            .apply()
    }
}
