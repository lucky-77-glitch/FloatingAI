package com.vano.floatingai

import android.content.Context

object AppPreferences {
    private const val FILE_NAME = "floating_ai_prefs"
    private const val KEY_BACKEND_URL = "backend_url"

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE)

    fun getBackendUrl(context: Context): String? =
        prefs(context).getString(KEY_BACKEND_URL, null)

    fun setBackendUrl(context: Context, url: String) {
        prefs(context).edit().putString(KEY_BACKEND_URL, url).apply()
    }
}
