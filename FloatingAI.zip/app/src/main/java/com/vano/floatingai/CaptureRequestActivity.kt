package com.vano.floatingai

import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/**
 * Activity transparan yang hanya menampilkan dialog izin perekaman layar milik
 * sistem Android. Layar tidak diambil sebelum pengguna menyetujui dialog ini.
 */
class CaptureRequestActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                FloatingService.sendCaptureEvent(
                    this,
                    FloatingService.ACTION_CAPTURE_GRANTED,
                    result.resultCode,
                    data
                )
                // Tahan sebentar supaya layanan sempat naik ke mode foreground
                // sementara aplikasi masih terlihat (syarat Android 14+).
                handler.postDelayed({ finish() }, FINISH_DELAY_MS)
            } else {
                FloatingService.sendCaptureEvent(this, FloatingService.ACTION_CAPTURE_DENIED)
                finish()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            FloatingService.sendCaptureEvent(this, FloatingService.ACTION_CAPTURE_DIALOG_SHOWN)
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            captureLauncher.launch(manager.createScreenCaptureIntent())
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private companion object {
        const val FINISH_DELAY_MS = 500L
    }
}
