package com.vano.floatingai

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.PixelFormat
import android.text.InputFilter
import android.util.Log
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.vano.floatingai.databinding.FloatingPanelBinding

/**
 * Mengelola panel asisten yang tampil sebagai overlay. Satu instance panel
 * dipakai ulang, jadi tidak pernah ada panel ganda.
 */
class FloatingPanelManager(
    serviceContext: Context,
    private val windowManager: WindowManager,
    private val listener: Listener
) {

    interface Listener {
        fun onPanelShown()
        fun onPanelHidden()
        fun onReadScreenRequested()
        fun onAnalyzeRequested(ocrText: String, question: String)
        fun onNewConversationRequested()
    }

    enum class StatusType { INFO, SUCCESS, ERROR }

    companion object {
        const val MAX_OCR_CHARS = 8000
        const val MAX_QUESTION_CHARS = 1000
        private const val TAG = "FloatingPanelManager"
    }

    private val context: Context =
        ContextThemeWrapper(serviceContext, R.style.Theme_FloatingAI)

    private var binding: FloatingPanelBinding? = null
    private var attached = false

    val isShowing: Boolean
        get() = attached

    // ---------- Tampil / sembunyi ----------

    fun show() {
        if (attached) return
        val b = ensureBinding()
        try {
            windowManager.addView(b.root, buildParams())
        } catch (e: Exception) {
            Log.w(TAG, "Gagal menampilkan panel: ${e.javaClass.simpleName}")
            Toast.makeText(context, R.string.toast_overlay_failed, Toast.LENGTH_LONG).show()
            return
        }
        attached = true
        listener.onPanelShown()
    }

    fun hide() {
        if (!attached) return
        val b = binding ?: return
        hideKeyboard(b.root)
        try {
            windowManager.removeView(b.root)
        } catch (e: IllegalArgumentException) {
            Log.w(TAG, "Panel sudah tidak terpasang")
        }
        attached = false
        listener.onPanelHidden()
    }

    /** Dipanggil saat rotasi atau perubahan ukuran layar. */
    fun onConfigurationChanged() {
        val b = binding ?: return
        if (!attached) return
        try {
            windowManager.updateViewLayout(b.root, buildParams())
        } catch (e: IllegalArgumentException) {
            Log.w(TAG, "Panel tidak terpasang saat update ukuran")
        }
    }

    /** Membersihkan panel sepenuhnya saat layanan berhenti. Tanpa callback. */
    fun release() {
        val b = binding
        if (attached && b != null) {
            hideKeyboard(b.root)
            try {
                windowManager.removeView(b.root)
            } catch (e: IllegalArgumentException) {
                Log.w(TAG, "Panel sudah tidak terpasang saat release")
            }
        }
        attached = false
        binding = null
    }

    // ---------- Pembaruan isi panel ----------

    fun setStatus(message: String?, type: StatusType = StatusType.INFO) {
        val b = ensureBinding()
        if (message.isNullOrBlank()) {
            b.txtStatus.text = ""
            b.txtStatus.visibility = View.GONE
        } else {
            val colorRes = when (type) {
                StatusType.INFO -> R.color.text_secondary
                StatusType.SUCCESS -> R.color.success
                StatusType.ERROR -> R.color.danger
            }
            b.txtStatus.text = message
            b.txtStatus.setTextColor(ContextCompat.getColor(context, colorRes))
            b.txtStatus.visibility = View.VISIBLE
        }
        updateStatusRow(b)
    }

    fun setBusy(busy: Boolean) {
        val b = ensureBinding()
        b.progress.visibility = if (busy) View.VISIBLE else View.GONE
        b.btnReadScreen.isEnabled = !busy
        b.btnAnalyze.isEnabled = !busy
        updateStatusRow(b)
    }

    fun setOcrText(text: String) {
        ensureBinding().inputOcr.setText(text)
    }

    fun setAnswer(text: String) {
        val b = ensureBinding()
        b.txtAnswer.text = text
        b.btnCopy.isEnabled = text.isNotBlank()
    }

    // ---------- Internal ----------

    private fun ensureBinding(): FloatingPanelBinding =
        binding ?: createBinding().also { binding = it }

    private fun createBinding(): FloatingPanelBinding {
        val b = FloatingPanelBinding.inflate(LayoutInflater.from(context))

        b.inputOcr.filters = arrayOf(InputFilter.LengthFilter(MAX_OCR_CHARS))
        b.inputQuestion.filters = arrayOf(InputFilter.LengthFilter(MAX_QUESTION_CHARS))
        b.btnCopy.isEnabled = false

        b.root.onBackPressed = { hide() }
        b.btnClose.setOnClickListener { hide() }
        b.btnReadScreen.setOnClickListener { listener.onReadScreenRequested() }
        b.btnAnalyze.setOnClickListener {
            listener.onAnalyzeRequested(
                b.inputOcr.text?.toString().orEmpty().trim(),
                b.inputQuestion.text?.toString().orEmpty().trim()
            )
        }
        b.btnCopy.setOnClickListener { copyAnswer() }
        b.btnNewChat.setOnClickListener {
            b.inputOcr.setText("")
            b.inputQuestion.setText("")
            setAnswer("")
            setStatus(null)
            listener.onNewConversationRequested()
        }
        return b
    }

    private fun updateStatusRow(b: FloatingPanelBinding) {
        val visible = b.txtStatus.visibility == View.VISIBLE ||
            b.progress.visibility == View.VISIBLE
        b.statusRow.visibility = if (visible) View.VISIBLE else View.GONE
    }

    private fun copyAnswer() {
        val text = binding?.txtAnswer?.text?.toString().orEmpty()
        if (text.isBlank()) return
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Jawaban AI", text))
        Toast.makeText(context, R.string.panel_copied, Toast.LENGTH_SHORT).show()
    }

    private fun hideKeyboard(view: View) {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(view.windowToken, 0)
    }

    private fun dp(value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()

    private fun buildParams(): WindowManager.LayoutParams {
        val metrics = context.resources.displayMetrics
        val margin = dp(12)
        val top = dp(40)

        val width = minOf(metrics.widthPixels - 2 * margin, dp(480)).coerceAtLeast(dp(200))
        val maxHeight = (metrics.heightPixels - top - margin).coerceAtLeast(dp(200))
        val height = (metrics.heightPixels * 0.65f).toInt()
            .coerceIn(minOf(dp(260), maxHeight), maxHeight)

        return WindowManager.LayoutParams(
            width,
            height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // Tanpa FLAG_NOT_FOCUSABLE supaya keyboard bisa dipakai di kolom input.
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = top
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
    }
}
