package com.vano.floatingai

import android.content.ClipData
import android.content.ClipboardManager
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.PixelFormat
import android.text.InputFilter
import android.util.Log
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.vano.floatingai.databinding.FloatingPanelBinding

/**
 * Mengelola panel asisten yang tampil sebagai overlay. Satu instance panel
 * dipakai ulang, jadi tidak pernah ada panel ganda.
 */
class FloatingPanelManager(
    serviceContext: Context,
    private val windowManager: WindowManager,
    private val listener: Listener
) {

    interface Listener {
        fun onPanelShown()
        fun onPanelHidden()
        fun onReadScreenRequested()
        fun onAnalyzeRequested(ocrText: String, question: String)
        fun onNewConversationRequested()
    }

    enum class StatusType { INFO, SUCCESS, ERROR }

    companion object {
        const val MAX_OCR_CHARS = 8000
        const val MAX_QUESTION_CHARS = 1000
        private const val MIN_WIDTH_DP = 220
        private const val MIN_HEIGHT_DP = 240
        private const val TAG = "FloatingPanelManager"
    }

    private val context: Context =
        ContextThemeWrapper(serviceContext, R.style.Theme_FloatingAI)

    private var binding: FloatingPanelBinding? = null
    private var attached = false
    private var params: WindowManager.LayoutParams? = null

    val isShowing: Boolean
        get() = attached

    // ---------- Tampil / sembunyi ----------

    fun show() {
        if (attached) return
        val b = ensureBinding()
        try {
            val p = buildParams()
            params = p
            windowManager.addView(b.root, p)
        } catch (e: Exception) {
            Log.w(TAG, "Gagal menampilkan panel: ${e.javaClass.simpleName}")
            Toast.makeText(context, R.string.toast_overlay_failed, Toast.LENGTH_LONG).show()
            return
        }
        attached = true
        listener.onPanelShown()
    }

    fun hide() {
        if (!attached) return
        val b = binding ?: return
        hideKeyboard(b.root)
        try {
            windowManager.removeView(b.root)
        } catch (e: IllegalArgumentException) {
            Log.w(TAG, "Panel sudah tidak terpasang")
        }
        attached = false
        listener.onPanelHidden()
    }

    /** Dipanggil saat rotasi atau perubahan ukuran layar. */
    fun onConfigurationChanged() {
        val b = binding ?: return
        if (!attached) return
        val p = params ?: return
        clampBounds(p)
        try {
            windowManager.updateViewLayout(b.root, p)
        } catch (e: IllegalArgumentException) {
            Log.w(TAG, "Panel tidak terpasang saat update ukuran")
        }
    }

    /** Membersihkan panel sepenuhnya saat layanan berhenti. Tanpa callback. */
    fun release() {
        val b = binding
        if (attached && b != null) {
            hideKeyboard(b.root)
            try {
                windowManager.removeView(b.root)
            } catch (e: IllegalArgumentException) {
                Log.w(TAG, "Panel sudah tidak terpasang saat release")
            }
        }
        attached = false
        binding = null
    }

    // ---------- Pembaruan isi panel ----------

    fun setStatus(message: String?, type: StatusType = StatusType.INFO) {
        val b = ensureBinding()
        if (message.isNullOrBlank()) {
            b.txtStatus.text = ""
            b.txtStatus.visibility = View.GONE
        } else {
            val colorRes = when (type) {
                StatusType.INFO -> R.color.text_secondary
                StatusType.SUCCESS -> R.color.success
                StatusType.ERROR -> R.color.danger
            }
            b.txtStatus.text = message
            b.txtStatus.setTextColor(ContextCompat.getColor(context, colorRes))
            b.txtStatus.visibility = View.VISIBLE
        }
        updateStatusRow(b)
    }

    fun setBusy(busy: Boolean) {
        val b = ensureBinding()
        b.progress.visibility = if (busy) View.VISIBLE else View.GONE
        b.btnReadScreen.isEnabled = !busy
        b.btnAnalyze.isEnabled = !busy
        updateStatusRow(b)
    }

    fun setOcrText(text: String) {
        ensureBinding().inputOcr.setText(text)
    }

    fun setAnswer(text: String) {
        val b = ensureBinding()
        b.txtAnswer.text = text
        b.btnCopy.isEnabled = text.isNotBlank()
    }

    // ---------- Internal ----------

    private fun ensureBinding(): FloatingPanelBinding =
        binding ?: createBinding().also { binding = it }

    private fun createBinding(): FloatingPanelBinding {
        val b = FloatingPanelBinding.inflate(LayoutInflater.from(context))

        b.inputOcr.filters = arrayOf(InputFilter.LengthFilter(MAX_OCR_CHARS))
        b.inputQuestion.filters = arrayOf(InputFilter.LengthFilter(MAX_QUESTION_CHARS))
        b.btnCopy.isEnabled = false

        setupDrag(b)
        setupResize(b)

        b.root.onBackPressed = { hide() }
        b.btnClose.setOnClickListener { hide() }
        b.btnReadScreen.setOnClickListener { listener.onReadScreenRequested() }
        b.btnAnalyze.setOnClickListener {
            listener.onAnalyzeRequested(
                b.inputOcr.text?.toString().orEmpty().trim(),
                b.inputQuestion.text?.toString().orEmpty().trim()
            )
        }
        b.btnCopy.setOnClickListener { copyAnswer() }
        b.btnNewChat.setOnClickListener {
            b.inputOcr.setText("")
            b.inputQuestion.setText("")
            setAnswer("")
            setStatus(null)
            listener.onNewConversationRequested()
        }
        return b
    }

    private fun updateStatusRow(b: FloatingPanelBinding) {
        val visible = b.txtStatus.visibility == View.VISIBLE ||
            b.progress.visibility == View.VISIBLE
        b.statusRow.visibility = if (visible) View.VISIBLE else View.GONE
    }

    private fun copyAnswer() {
        val text = binding?.txtAnswer?.text?.toString().orEmpty()
        if (text.isBlank()) return
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Jawaban AI", text))
        Toast.makeText(context, R.string.panel_copied, Toast.LENGTH_SHORT).show()
    }

    private fun hideKeyboard(view: View) {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
        imm?.hideSoftInputFromWindow(view.windowToken, 0)
    }

    private fun dp(value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()

    // ---------- Geser dan ubah ukuran ----------

    private fun screenWidth() = context.resources.displayMetrics.widthPixels
    private fun screenHeight() = context.resources.displayMetrics.heightPixels

    /** Menjaga panel tetap di dalam layar dan tidak lebih kecil dari ukuran minimum. */
    private fun clampBounds(p: WindowManager.LayoutParams) {
        val sw = screenWidth()
        val sh = screenHeight()
        p.width = p.width.coerceIn(minOf(dp(MIN_WIDTH_DP), sw), sw)
        p.height = p.height.coerceIn(minOf(dp(MIN_HEIGHT_DP), sh), sh)
        p.x = p.x.coerceIn(0, maxOf(0, sw - p.width))
        p.y = p.y.coerceIn(0, maxOf(0, sh - p.height))
    }

    private fun applyLayout(b: FloatingPanelBinding, p: WindowManager.LayoutParams) {
        if (!attached) return
        try {
            windowManager.updateViewLayout(b.root, p)
        } catch (e: IllegalArgumentException) {
            Log.w(TAG, "Panel tidak terpasang saat memperbarui tata letak")
        }
    }

    private fun saveBounds(p: WindowManager.LayoutParams) {
        AppPreferences.setPanelBounds(context, p.x, p.y, p.width, p.height)
    }

    /** Menggeser panel dengan menyeret bagian judul. */
    @SuppressLint("ClickableViewAccessibility")
    private fun setupDrag(b: FloatingPanelBinding) {
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        b.panelHeader.setOnTouchListener { _, ev ->
            val p = params ?: return@setOnTouchListener false
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX
                    downY = ev.rawY
                    startX = p.x
                    startY = p.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = startX + (ev.rawX - downX).toInt()
                    p.y = startY + (ev.rawY - downY).toInt()
                    clampBounds(p)
                    applyLayout(b, p)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    saveBounds(p)
                    true
                }
                else -> false
            }
        }
    }

    /** Mengubah ukuran panel dengan menyeret pegangan di pojok kanan bawah. */
    @SuppressLint("ClickableViewAccessibility")
    private fun setupResize(b: FloatingPanelBinding) {
        var downX = 0f
        var downY = 0f
        var startW = 0
        var startH = 0
        b.resizeHandle.setOnTouchListener { _, ev ->
            val p = params ?: return@setOnTouchListener false
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX
                    downY = ev.rawY
                    startW = p.width
                    startH = p.height
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val maxW = (screenWidth() - p.x).coerceAtLeast(1)
                    val maxH = (screenHeight() - p.y).coerceAtLeast(1)
                    p.width = (startW + (ev.rawX - downX).toInt())
                        .coerceIn(minOf(dp(MIN_WIDTH_DP), maxW), maxW)
                    p.height = (startH + (ev.rawY - downY).toInt())
                        .coerceIn(minOf(dp(MIN_HEIGHT_DP), maxH), maxH)
                    applyLayout(b, p)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    saveBounds(p)
                    true
                }
                else -> false
            }
        }
    }

    private fun buildParams(): WindowManager.LayoutParams {
        val sw = screenWidth()
        val sh = screenHeight()
        val saved = AppPreferences.getPanelBounds(context)

        val startX: Int
        val startY: Int
        val width: Int
        val height: Int
        if (saved != null && saved[2] > 0 && saved[3] > 0) {
            startX = saved[0]
            startY = saved[1]
            width = saved[2]
            height = saved[3]
        } else {
            val margin = dp(12)
            val top = dp(40)
            width = minOf(sw - 2 * margin, dp(480)).coerceAtLeast(dp(MIN_WIDTH_DP))
            val maxHeight = (sh - top - margin).coerceAtLeast(dp(200))
            height = (sh * 0.65f).toInt()
                .coerceIn(minOf(dp(260), maxHeight), maxHeight)
            startX = (sw - width) / 2
            startY = top
        }

        return WindowManager.LayoutParams(
            width,
            height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            // Tanpa FLAG_NOT_FOCUSABLE supaya keyboard bisa dipakai di kolom input.
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = startX
            y = startY
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
            clampBounds(this)
        }
    }
}
