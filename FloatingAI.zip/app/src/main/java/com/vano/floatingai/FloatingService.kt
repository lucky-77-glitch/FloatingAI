package com.vano.floatingai

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.vano.floatingai.databinding.FloatingRobotBinding
import kotlin.math.abs

class FloatingService : Service() {

    companion object {
        const val ACTION_STOP = "com.vano.floatingai.action.STOP"
        private const val MAX_HISTORY_MESSAGES = 12
        private const val HISTORY_ANSWER_CHARS = 3000

        private const val TAG = "FloatingService"
        private const val CHANNEL_ID = "floating_ai_service"
        private const val NOTIFICATION_ID = 1001

        @Volatile
        var isRunning: Boolean = false
            private set

        fun start(context: Context) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, FloatingService::class.java)
            )
        }
    }

    private lateinit var windowManager: WindowManager
    private var robotBinding: FloatingRobotBinding? = null
    private var robotParams: WindowManager.LayoutParams? = null
    private var bobAnimator: ObjectAnimator? = null
    private var snapAnimator: ValueAnimator? = null
    private lateinit var panelManager: FloatingPanelManager
    private val aiClient = AIClient()
    private val conversation = mutableListOf<AIClient.Turn>()

    private val panelListener = object : FloatingPanelManager.Listener {
        override fun onPanelShown() {
            // Sembunyikan robot selama panel terbuka.
            robotBinding?.root?.visibility = View.GONE
        }

        override fun onPanelHidden() {
            robotBinding?.root?.visibility = View.VISIBLE
        }

        override fun onReadScreenRequested() {
            // Diganti dengan alur MediaProjection + OCR pada Tahap 4.
            panelManager.setStatus(
                getString(R.string.panel_status_read_unavailable),
                FloatingPanelManager.StatusType.INFO
            )
        }

        override fun onAnalyzeRequested(ocrText: String, question: String) {
            if (ocrText.isBlank() && question.isBlank()) {
                panelManager.setStatus(
                    getString(R.string.panel_error_empty_input),
                    FloatingPanelManager.StatusType.ERROR
                )
                return
            }
            val service = this@FloatingService
            val backendUrl = AppPreferences.getBackendUrl(service)
            if (backendUrl.isNullOrBlank()) {
                panelManager.setStatus(
                    getString(R.string.ai_error_not_configured),
                    FloatingPanelManager.StatusType.ERROR
                )
                return
            }
            panelManager.setBusy(true)
            panelManager.setStatus(
                getString(R.string.ai_status_loading),
                FloatingPanelManager.StatusType.INFO
            )
            aiClient.ask(
                backendUrl,
                AppPreferences.getAccessToken(service).orEmpty(),
                ocrText,
                question,
                conversation.toList()
            ) { result -> handleAiResult(question, result) }
        }

        override fun onNewConversationRequested() {
            aiClient.cancelPending()
            conversation.clear()
            panelManager.setBusy(false)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        panelManager = FloatingPanelManager(this, windowManager, panelListener)
        createNotificationChannel()
        isRunning = true
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }

        // Wajib segera masuk mode foreground setelah startForegroundService().
        if (!promoteToForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.toast_overlay_needed, Toast.LENGTH_LONG).show()
            stopSelf()
            return START_NOT_STICKY
        }

        showRobot()
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (::panelManager.isInitialized) panelManager.onConfigurationChanged()
        val binding = robotBinding
        val params = robotParams
        if (binding != null && params != null) {
            clampToScreen(params)
            updateLayoutSafely(binding.root, params)
        }
    }

    override fun onDestroy() {
        aiClient.shutdown()
        if (::panelManager.isInitialized) panelManager.release()
        removeRobot()
        isRunning = false
        super.onDestroy()
    }

    // ---------- Hasil AI ----------

    private fun handleAiResult(question: String, result: AIClient.Result) {
        panelManager.setBusy(false)
        when (result) {
            is AIClient.Result.Success -> {
                conversation.add(
                    AIClient.Turn("user", question.ifBlank { getString(R.string.ai_default_question) })
                )
                conversation.add(AIClient.Turn("assistant", result.answer.take(HISTORY_ANSWER_CHARS)))
                while (conversation.size > MAX_HISTORY_MESSAGES) {
                    conversation.removeAt(0)
                    conversation.removeAt(0)
                }
                panelManager.setAnswer(result.answer)
                val messageRes =
                    if (result.truncated) R.string.ai_status_truncated else R.string.ai_status_done
                panelManager.setStatus(
                    getString(messageRes),
                    FloatingPanelManager.StatusType.SUCCESS
                )
            }
            is AIClient.Result.Failure -> {
                panelManager.setStatus(
                    getString(errorMessageRes(result.kind)),
                    FloatingPanelManager.StatusType.ERROR
                )
            }
        }
    }

    private fun errorMessageRes(kind: AIClient.ErrorKind): Int = when (kind) {
        AIClient.ErrorKind.NETWORK -> R.string.ai_error_network
        AIClient.ErrorKind.TIMEOUT -> R.string.ai_error_timeout
        AIClient.ErrorKind.UNAUTHORIZED -> R.string.ai_error_unauthorized
        AIClient.ErrorKind.RATE_LIMITED -> R.string.ai_error_rate_limited
        AIClient.ErrorKind.INPUT_TOO_LARGE -> R.string.ai_error_too_large
        AIClient.ErrorKind.SERVER -> R.string.ai_error_server
        AIClient.ErrorKind.BAD_RESPONSE -> R.string.ai_error_bad_response
    }

    // ---------- Robot mengambang ----------

    private fun showRobot() {
        if (robotBinding != null) return // cegah overlay ganda

        val themedContext = ContextThemeWrapper(this, R.style.Theme_FloatingAI)
        val binding = FloatingRobotBinding.inflate(LayoutInflater.from(themedContext))

        val size = resources.getDimensionPixelSize(R.dimen.floating_robot_size)
        val metrics = resources.displayMetrics

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = metrics.widthPixels - size
            y = metrics.heightPixels / 3
        }

        try {
            windowManager.addView(binding.root, params)
        } catch (e: Exception) {
            // SecurityException, BadTokenException, dll.
            Log.w(TAG, "Gagal menambahkan overlay: ${e.javaClass.simpleName}")
            Toast.makeText(this, R.string.toast_overlay_failed, Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }

        robotBinding = binding
        robotParams = params
        setupInteractions(binding, params)
        startBobbing(binding)
    }

    private fun removeRobot() {
        bobAnimator?.cancel()
        bobAnimator = null
        snapAnimator?.cancel()
        snapAnimator = null

        robotBinding?.let { binding ->
            try {
                windowManager.removeView(binding.root)
            } catch (e: IllegalArgumentException) {
                Log.w(TAG, "View overlay sudah tidak terpasang")
            }
        }
        robotBinding = null
        robotParams = null
    }

    private fun onRobotClicked() {
        panelManager.show()
    }

    @Suppress("ClickableViewAccessibility")
    private fun setupInteractions(
        binding: FloatingRobotBinding,
        params: WindowManager.LayoutParams
    ) {
        val touchSlop = ViewConfiguration.get(this).scaledTouchSlop
        var startX = 0
        var startY = 0
        var downRawX = 0f
        var downRawY = 0f
        var dragging = false

        binding.robotClose.setOnClickListener { stopSelf() }
        binding.root.setOnClickListener { onRobotClicked() }

        binding.root.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    snapAnimator?.cancel()
                    startX = params.x
                    startY = params.y
                    downRawX = event.rawX
                    downRawY = event.rawY
                    dragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downRawX).toInt()
                    val dy = (event.rawY - downRawY).toInt()
                    if (!dragging && (abs(dx) > touchSlop || abs(dy) > touchSlop)) {
                        dragging = true
                    }
                    if (dragging) {
                        params.x = startX + dx
                        params.y = startY + dy
                        clampToScreen(params)
                        updateLayoutSafely(view, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (dragging) snapToEdge(view, params) else view.performClick()
                    true
                }
                MotionEvent.ACTION_CANCEL -> {
                    if (dragging) snapToEdge(view, params)
                    true
                }
                else -> false
            }
        }
    }

    private fun startBobbing(binding: FloatingRobotBinding) {
        bobAnimator?.cancel()
        bobAnimator = ObjectAnimator.ofFloat(
            binding.robotImage,
            View.TRANSLATION_Y,
            0f,
            -6f * resources.displayMetrics.density
        ).apply {
            duration = 1200L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }

    private fun snapToEdge(view: View, params: WindowManager.LayoutParams) {
        val size = resources.getDimensionPixelSize(R.dimen.floating_robot_size)
        val screenWidth = resources.displayMetrics.widthPixels
        val target = if (params.x + size / 2 < screenWidth / 2) 0 else screenWidth - size

        snapAnimator?.cancel()
        snapAnimator = ValueAnimator.ofInt(params.x, target).apply {
            duration = 180L
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { animator ->
                params.x = animator.animatedValue as Int
                updateLayoutSafely(view, params)
            }
            start()
        }
    }

    private fun clampToScreen(params: WindowManager.LayoutParams) {
        val metrics = resources.displayMetrics
        val size = resources.getDimensionPixelSize(R.dimen.floating_robot_size)
        params.x = params.x.coerceIn(0, (metrics.widthPixels - size).coerceAtLeast(0))
        params.y = params.y.coerceIn(0, (metrics.heightPixels - size).coerceAtLeast(0))
    }

    private fun updateLayoutSafely(view: View, params: WindowManager.LayoutParams) {
        if (robotBinding?.root !== view) return
        try {
            windowManager.updateViewLayout(view, params)
        } catch (e: IllegalArgumentException) {
            Log.w(TAG, "View overlay tidak terpasang saat update posisi")
        }
    }

    // ---------- Notifikasi foreground ----------

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.notif_channel_name),
            NotificationManager.IMPORTANCE_LOW
        )
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun promoteToForeground(): Boolean {
        return try {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                buildNotification(),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
            true
        } catch (e: Exception) {
            Log.w(TAG, "Gagal masuk mode foreground: ${e.javaClass.simpleName}")
            false
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopIntent = PendingIntent.getService(
            this,
            1,
            Intent(this, FloatingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_robot)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(getString(R.string.notif_text))
            .setContentIntent(openIntent)
            .addAction(0, getString(R.string.notif_stop), stopIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }
}
