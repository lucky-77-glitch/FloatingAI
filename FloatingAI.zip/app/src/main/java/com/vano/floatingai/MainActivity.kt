package com.vano.floatingai

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.vano.floatingai.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    companion object {
        private const val STATE_START_AFTER_NOTIF = "start_after_notif"
    }

    private lateinit var binding: ActivityMainBinding

    // true bila permintaan izin notifikasi berasal dari tombol Start.
    private var startAfterNotificationRequest = false

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            val startAfter = startAfterNotificationRequest
            startAfterNotificationRequest = false
            if (startAfter) {
                // Layanan tetap boleh berjalan walau notifikasi ditolak.
                launchFloating()
            } else if (!granted &&
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                !shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)
            ) {
                // Ditolak permanen: arahkan ke pengaturan aplikasi.
                openSettings(PermissionHelper.appNotificationSettingsIntent(this))
            }
            refreshStatus()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        startAfterNotificationRequest =
            savedInstanceState?.getBoolean(STATE_START_AFTER_NOTIF, false) ?: false

        binding.btnGrantOverlay.setOnClickListener {
            openSettings(PermissionHelper.overlaySettingsIntent(this))
        }
        binding.btnGrantNotif.setOnClickListener {
            startAfterNotificationRequest = false
            requestNotificationPermission()
        }
        binding.btnStart.setOnClickListener { onStartClicked() }
        binding.btnStop.setOnClickListener {
            stopService(Intent(this, FloatingService::class.java))
            binding.root.postDelayed({ refreshStatus() }, 300L)
        }
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean(STATE_START_AFTER_NOTIF, startAfterNotificationRequest)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun onStartClicked() {
        if (!PermissionHelper.hasOverlayPermission(this)) {
            Toast.makeText(this, R.string.toast_overlay_needed, Toast.LENGTH_LONG).show()
            openSettings(PermissionHelper.overlaySettingsIntent(this))
            return
        }
        if (!PermissionHelper.hasNotificationPermission(this)) {
            startAfterNotificationRequest = true
            requestNotificationPermission()
            return
        }
        launchFloating()
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun launchFloating() {
        FloatingService.start(this)
        binding.root.postDelayed({ refreshStatus() }, 300L)
    }

    private fun openSettings(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.toast_settings_unavailable, Toast.LENGTH_LONG).show()
        }
    }

    private fun refreshStatus() {
        val overlayGranted = PermissionHelper.hasOverlayPermission(this)
        setStatus(
            binding.txtOverlayStatus,
            if (overlayGranted) R.string.overlay_granted else R.string.overlay_missing,
            overlayGranted
        )
        binding.btnGrantOverlay.visibility = if (overlayGranted) View.GONE else View.VISIBLE

        val notifGranted = PermissionHelper.hasNotificationPermission(this)
        setStatus(
            binding.txtNotifStatus,
            if (notifGranted) R.string.notif_granted else R.string.notif_missing,
            notifGranted
        )
        binding.btnGrantNotif.visibility = if (notifGranted) View.GONE else View.VISIBLE

        val running = FloatingService.isRunning
        setStatus(
            binding.txtServiceStatus,
            if (running) R.string.service_running else R.string.service_stopped,
            running
        )

        val aiConfigured = !AppPreferences.getBackendUrl(this).isNullOrBlank()
        val aiTested = aiConfigured && AppPreferences.isBackendTested(this)
        setStatus(
            binding.txtAiStatus,
            when {
                !aiConfigured -> R.string.ai_not_configured
                aiTested -> R.string.ai_connected
                else -> R.string.ai_configured
            },
            aiTested
        )
    }

    private fun setStatus(view: TextView, textRes: Int, ok: Boolean) {
        view.setText(textRes)
        view.setTextColor(
            ContextCompat.getColor(this, if (ok) R.color.success else R.color.warning)
        )
    }
}
