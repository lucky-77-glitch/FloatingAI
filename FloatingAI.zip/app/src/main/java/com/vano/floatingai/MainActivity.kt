package com.vano.floatingai

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.vano.floatingai.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
            // Layanan tetap boleh berjalan walau notifikasi ditolak.
            launchFloating()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnGrantOverlay.setOnClickListener { requestOverlayPermission() }
        binding.btnStart.setOnClickListener { onStartClicked() }
        binding.btnStop.setOnClickListener {
            stopService(Intent(this, FloatingService::class.java))
            binding.root.postDelayed({ refreshStatus() }, 300L)
        }
        binding.btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    private fun onStartClicked() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.toast_overlay_needed, Toast.LENGTH_LONG).show()
            requestOverlayPermission()
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }
        launchFloating()
    }

    private fun launchFloating() {
        FloatingService.start(this)
        binding.root.postDelayed({ refreshStatus() }, 300L)
    }

    private fun requestOverlayPermission() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        try {
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.toast_overlay_unavailable, Toast.LENGTH_LONG).show()
        }
    }

    private fun refreshStatus() {
        val overlayGranted = Settings.canDrawOverlays(this)
        setStatus(
            binding.txtOverlayStatus,
            if (overlayGranted) R.string.overlay_granted else R.string.overlay_missing,
            overlayGranted
        )
        binding.btnGrantOverlay.visibility = if (overlayGranted) View.GONE else View.VISIBLE

        val running = FloatingService.isRunning
        setStatus(
            binding.txtServiceStatus,
            if (running) R.string.service_running else R.string.service_stopped,
            running
        )

        val aiConfigured = !AppPreferences.getBackendUrl(this).isNullOrBlank()
        setStatus(
            binding.txtAiStatus,
            if (aiConfigured) R.string.ai_configured else R.string.ai_not_configured,
            aiConfigured
        )
    }

    private fun setStatus(view: TextView, textRes: Int, ok: Boolean) {
        view.setText(textRes)
        view.setTextColor(
            ContextCompat.getColor(this, if (ok) R.color.teal else R.color.warning)
        )
    }
}
