package com.vano.floatingai

import android.content.Context
import android.util.AttributeSet
import android.view.KeyEvent
import android.widget.FrameLayout

/**
 * Root panel overlay. Jendela overlay tidak punya Activity, jadi tombol Back
 * ditangani di sini agar panel bisa ditutup dengan Back.
 */
class PanelFrameLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    var onBackPressed: (() -> Unit)? = null

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_BACK && onBackPressed != null) {
            if (event.action == KeyEvent.ACTION_UP) {
                onBackPressed?.invoke()
            }
            return true
        }
        return super.dispatchKeyEvent(event)
    }
}
