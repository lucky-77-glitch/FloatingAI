package com.vano.floatingai

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager

/**
 * Mengambil SATU frame layar lewat MediaProjection setelah pengguna menyetujui
 * dialog sistem Android, lalu langsung menghentikan seluruh sesi. Gambar hanya
 * ada di memori dan tidak pernah disimpan ke penyimpanan.
 */
class ScreenCaptureManager(private val context: Context) {

    enum class Failure { UNAVAILABLE, TIMEOUT, ERROR }

    interface Callback {
        fun onCaptured(bitmap: Bitmap)
        fun onFailed(reason: Failure)
    }

    private class ScreenSpec(val width: Int, val height: Int, val densityDpi: Int)

    companion object {
        private const val TAG = "ScreenCaptureManager"
        private const val FRAME_TIMEOUT_MS = 5000L
        private const val MAX_SIDE_PX = 3000
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    private var active = false
    private var callback: Callback? = null
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var workerThread: HandlerThread? = null
    private var timeoutRunnable: Runnable? = null

    @Volatile
    private var frameHandled = false

    val isActive: Boolean
        get() = active

    /** Dipanggil di main thread. Hasil dikembalikan di main thread. */
    fun captureOnce(resultCode: Int, data: Intent, callback: Callback) {
        if (active) {
            callback.onFailed(Failure.ERROR)
            return
        }
        active = true
        frameHandled = false
        this.callback = callback

        val manager = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val newProjection = try {
            manager.getMediaProjection(resultCode, data)
        } catch (e: Exception) {
            Log.w(TAG, "getMediaProjection gagal: ${e.javaClass.simpleName}")
            null
        }
        if (newProjection == null) {
            fail(Failure.UNAVAILABLE)
            return
        }
        projection = newProjection

        // Android 14+: callback wajib didaftarkan sebelum membuat VirtualDisplay.
        newProjection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                // Sesi dihentikan sistem atau pengguna sebelum frame diterima.
                mainHandler.post { if (active) fail(Failure.ERROR) }
            }
        }, mainHandler)

        val spec = readScreenSpec()
        val thread = HandlerThread("FloatingAI-capture").also { it.start() }
        workerThread = thread

        val reader = ImageReader.newInstance(spec.width, spec.height, PixelFormat.RGBA_8888, 2)
        imageReader = reader
        reader.setOnImageAvailableListener(
            { r -> handleImage(r, spec.width, spec.height) },
            Handler(thread.looper)
        )

        try {
            virtualDisplay = newProjection.createVirtualDisplay(
                "FloatingAI-capture",
                spec.width,
                spec.height,
                spec.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface,
                null,
                null
            )
        } catch (e: Exception) {
            Log.w(TAG, "createVirtualDisplay gagal: ${e.javaClass.simpleName}")
            fail(Failure.ERROR)
            return
        }

        val timeout = Runnable { if (active) fail(Failure.TIMEOUT) }
        timeoutRunnable = timeout
        mainHandler.postDelayed(timeout, FRAME_TIMEOUT_MS)
    }

    /** Menghentikan sesi tanpa memanggil callback (mis. saat layanan berhenti). */
    fun release() {
        callback = null
        releaseResources()
    }

    // ---------- Internal ----------

    private fun handleImage(reader: ImageReader, width: Int, height: Int) {
        if (!active || frameHandled) return
        val image = try {
            reader.acquireLatestImage()
        } catch (e: Exception) {
            null
        } ?: return
        frameHandled = true

        var bitmap: Bitmap? = null
        try {
            bitmap = imageToBitmap(image, width, height)
        } catch (e: Exception) {
            Log.w(TAG, "Konversi gambar gagal: ${e.javaClass.simpleName}")
        } finally {
            image.close()
        }

        val result = bitmap
        mainHandler.post {
            if (!active) {
                result?.recycle()
                return@post
            }
            val cb = callback
            releaseResources() // hentikan proyeksi segera setelah satu frame didapat
            if (result != null) {
                cb?.onCaptured(result)
            } else {
                cb?.onFailed(Failure.ERROR)
            }
        }
    }

    private fun imageToBitmap(image: Image, width: Int, height: Int): Bitmap {
        val plane = image.planes[0]
        val pixelStride = plane.pixelStride
        val rowPadding = plane.rowStride - pixelStride * width
        val padded = Bitmap.createBitmap(
            width + rowPadding / pixelStride,
            height,
            Bitmap.Config.ARGB_8888
        )
        padded.copyPixelsFromBuffer(plane.buffer)
        if (padded.width == width) return padded
        val cropped = Bitmap.createBitmap(padded, 0, 0, width, height)
        padded.recycle()
        return cropped
    }

    private fun fail(reason: Failure) {
        val cb = callback
        releaseResources()
        cb?.onFailed(reason)
    }

    private fun releaseResources() {
        active = false
        callback = null
        timeoutRunnable?.let { mainHandler.removeCallbacks(it) }
        timeoutRunnable = null

        virtualDisplay?.release()
        virtualDisplay = null

        imageReader?.setOnImageAvailableListener(null, null)
        imageReader?.close()
        imageReader = null

        projection?.stop()
        projection = null

        workerThread?.quitSafely()
        workerThread = null
    }

    @Suppress("DEPRECATION")
    private fun readScreenSpec(): ScreenSpec {
        val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val densityDpi = context.resources.displayMetrics.densityDpi

        var width: Int
        var height: Int
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val bounds = windowManager.maximumWindowMetrics.bounds
            width = bounds.width()
            height = bounds.height()
        } else {
            val metrics = DisplayMetrics()
            windowManager.defaultDisplay.getRealMetrics(metrics)
            width = metrics.widthPixels
            height = metrics.heightPixels
        }

        val longest = maxOf(width, height)
        if (longest > MAX_SIDE_PX) {
            val scale = MAX_SIDE_PX.toFloat() / longest
            width = (width * scale).toInt()
            height = (height * scale).toInt()
        }
        return ScreenSpec(maxOf(width, 1), maxOf(height, 1), densityDpi)
    }
}
