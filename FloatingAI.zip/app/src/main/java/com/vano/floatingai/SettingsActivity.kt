package com.vano.floatingai

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.vano.floatingai.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.inputBackendUrl.setText(AppPreferences.getBackendUrl(this).orEmpty())
        binding.btnSave.setOnClickListener { save() }
        binding.btnBack.setOnClickListener { finish() }
    }

    private fun save() {
        val value = binding.inputBackendUrl.text?.toString().orEmpty().trim().trimEnd('/')
        if (value.isNotEmpty() && !isValidHttpsUrl(value)) {
            binding.layoutBackendUrl.error = getString(R.string.settings_invalid)
            return
        }
        binding.layoutBackendUrl.error = null
        AppPreferences.setBackendUrl(this, value)
        Toast.makeText(this, R.string.settings_saved, Toast.LENGTH_SHORT).show()
    }

    private fun isValidHttpsUrl(value: String): Boolean {
        val uri = Uri.parse(value)
        return uri.scheme == "https" && !uri.host.isNullOrBlank()
    }
}
