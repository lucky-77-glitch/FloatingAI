package com.vano.floatingai

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.vano.floatingai.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private val aiClient = AIClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.inputBackendUrl.setText(AppPreferences.getBackendUrl(this).orEmpty())
        binding.inputAccessToken.setText(AppPreferences.getAccessToken(this).orEmpty())

        binding.btnSave.setOnClickListener {
            if (save()) {
                Toast.makeText(this, R.string.settings_saved, Toast.LENGTH_SHORT).show()
            }
        }
        binding.btnTest.setOnClickListener { testConnection() }
        binding.btnBack.setOnClickListener { finish() }
    }

    override fun onDestroy() {
        aiClient.shutdown()
        super.onDestroy()
    }

    private fun save(): Boolean {
        val url = binding.inputBackendUrl.text?.toString().orEmpty().trim().trimEnd('/')
        val token = binding.inputAccessToken.text?.toString().orEmpty().trim()

        if (url.isNotEmpty() && !isValidHttpsUrl(url)) {
            binding.layoutBackendUrl.error = getString(R.string.settings_invalid)
            return false
        }
        binding.layoutBackendUrl.error = null
        AppPreferences.setBackendUrl(this, url)
        AppPreferences.setAccessToken(this, token)
        return true
    }

    private fun testConnection() {
        if (!save()) return
        val url = AppPreferences.getBackendUrl(this)
        if (url.isNullOrBlank()) {
            showTestResult(R.string.settings_need_url, false)
            return
        }
        binding.btnTest.isEnabled = false
        showTestResult(R.string.settings_test_running, null)
        aiClient.checkHealth(url) { ok ->
            if (isFinishing || isDestroyed) return@checkHealth
            binding.btnTest.isEnabled = true
            AppPreferences.setBackendTested(this, ok)
            showTestResult(
                if (ok) R.string.settings_test_ok else R.string.settings_test_fail,
                ok
            )
        }
    }

    private fun showTestResult(textRes: Int, ok: Boolean?) {
        val colorRes = when (ok) {
            true -> R.color.success
            false -> R.color.danger
            null -> R.color.text_secondary
        }
        binding.txtTestResult.setText(textRes)
        binding.txtTestResult.setTextColor(ContextCompat.getColor(this, colorRes))
        binding.txtTestResult.visibility = android.view.View.VISIBLE
    }

    private fun isValidHttpsUrl(value: String): Boolean {
        val uri = Uri.parse(value)
        return uri.scheme == "https" && !uri.host.isNullOrBlank()
    }
}
