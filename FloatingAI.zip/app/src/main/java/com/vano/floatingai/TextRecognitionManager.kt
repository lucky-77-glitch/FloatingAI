package com.vano.floatingai

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/**
 * OCR di perangkat (ML Kit, model Latin ter-bundel) sehingga gambar layar tidak
 * dikirim ke mana pun. Aksara Latin mencakup bahasa Indonesia dan Inggris.
 */
class TextRecognitionManager {

    sealed class Result {
        data class Success(val text: String, val truncated: Boolean) : Result()
        object Empty : Result()
        object Failure : Result()
    }

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    /** Hasil dikembalikan di main thread. Bitmap tidak di-recycle di sini. */
    fun recognize(bitmap: Bitmap, maxChars: Int, onResult: (Result) -> Unit) {
        val image = try {
            InputImage.fromBitmap(bitmap, 0)
        } catch (e: Exception) {
            onResult(Result.Failure)
            return
        }
        recognizer.process(image)
            .addOnSuccessListener { text -> onResult(buildResult(text, maxChars)) }
            .addOnFailureListener { onResult(Result.Failure) }
    }

    fun close() {
        recognizer.close()
    }

    /**
     * Urutan blok dan baris mengikuti urutan baca dari ML Kit. Antar blok diberi
     * satu baris kosong supaya paragraf tetap terpisah.
     */
    private fun buildResult(text: Text, maxChars: Int): Result {
        val paragraphs = text.textBlocks.mapNotNull { block ->
            val lines = block.lines.map { it.text.trim() }.filter { it.isNotEmpty() }
            if (lines.isEmpty()) null else lines.joinToString("\n")
        }
        val full = paragraphs.joinToString("\n\n").trim()
        if (full.isEmpty()) return Result.Empty
        return if (full.length > maxChars) {
            Result.Success(full.take(maxChars), true)
        } else {
            Result.Success(full, false)
        }
    }
}
